<!DOCTYPE html>
<html lang="en">
<head>
  <title>Header for orders</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    
    <ul class="nav navbar-nav">
      
      <li><a href="asiakkaat.php">Asiakkaat</a></li>
      <li><a href="tuotteet.php">Tuotteet</a></li>
      <li><a href="tilaukset.php">Tilaukset</a></li>
      <li><a href="tilausrivit.php">Tilausrivit</a></li>
      <li><a href="laskut.php">Laskut</a></li>
    </ul>
  </div>
</nav>